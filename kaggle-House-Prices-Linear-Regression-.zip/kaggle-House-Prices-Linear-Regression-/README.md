# kaggle-House-Prices-Linear-Regression-
Solução do problema do preço das casas disponivel no kaggle usando um modelo simples de regressão linear
